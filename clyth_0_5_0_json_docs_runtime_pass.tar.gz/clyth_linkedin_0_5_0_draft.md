For the past few years, I’ve had a question sitting in the back of my mind:

If I were designing a systems language today, knowing what we’ve learned from C, C++, Rust, Go, Zig, modern backend tooling, and LLVM-based workflows, what decisions would I make differently?

That question eventually turned into Clyth — an experimental systems programming language I’ve been building in C++ with an LLVM-based ahead-of-time compiler.

The project started as a compiler experiment, but the more I worked on it, the more obvious one lesson became: a language is not just a compiler. The compiler should understand and lower the language, but the runtime and module ecosystem are where a lot of practical application-building power belongs.

That became the major direction behind the 0.5.0 alpha work.

Clyth now has a stronger language foundation with explicit `this`, first-class function types, lambda callbacks, struct constructors, native strings, collections, and a return-code based regression suite. The runtime side also expanded with file I/O, rapidhash-backed collections, JSON module direction, and HTTP/HTTPS/router API surfaces.

The backend runtime direction is built around Clyth-owned modules that integrate proven C libraries underneath the surface: libuv for event-loop/runtime scheduling direction, llhttp for HTTP parsing, OpenSSL for TLS/HTTPS, and wslay for WebSocket framing. Those libraries are implementation pieces, not the public API. The goal is for Clyth code to feel like Clyth, not like a thin wrapper around someone else’s C interface.

Clyth is not meant to replace C++, Rust, Go, Zig, or any other language. Those ecosystems solve real problems and have decades of engineering behind them. Instead, Clyth is about studying what makes those languages successful, taking inspiration from their strengths, and experimenting with areas where I think there is still room to explore different tradeoffs.

One of the long-term ideas I’m most interested in is MECC: Managed Entanglement for Collapsible Collections. MECC is an experiment around deterministic memory ownership and cleanup at the estate/lifetime-group level. Maybe it works, or maybe I arrive at the same conclusion of why no one in the industry has done things this way. Either way, the process of exploring those tradeoffs and understanding why certain designs succeed or fail is the valuable part.

I also want to be transparent that AI tools have been part of my development workflow. I treat AI as an engineering assistant: useful for iteration, review, debugging, refactoring, and exploring implementation paths faster. Architecture decisions, tradeoffs, verification, release direction, and final responsibility remain mine. At the end of the day, tools evolve, but engineers are still responsible for understanding what they build.

Clyth is still alpha software. There is a lot left to do: standalone module packaging, deeper JSON support, actual backend applications, LSP/editor tooling, and eventually MECC. But 0.5.0 is the point where the project feels less like “I built a compiler” and more like “I’m building a language ecosystem.”

Repo:
https://github.com/mali5820k/Cobralyth

Docs:
https://mali5820k.github.io/clyth-docs/
