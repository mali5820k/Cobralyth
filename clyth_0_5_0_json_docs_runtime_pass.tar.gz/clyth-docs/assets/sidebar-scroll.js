(function () {
  const key = "clyth-docs-sidebar-scroll";

  function sidebar() {
    return document.querySelector(".sidebar") || document.querySelector("[data-sidebar]");
  }

  function restore() {
    const el = sidebar();
    if (!el) return;
    const saved = window.localStorage.getItem(key);
    if (saved !== null) {
      el.scrollTop = Number(saved) || 0;
    }
  }

  function persist() {
    const el = sidebar();
    if (!el) return;
    window.localStorage.setItem(key, String(el.scrollTop || 0));
  }

  window.addEventListener("DOMContentLoaded", restore);
  window.addEventListener("beforeunload", persist);
  document.addEventListener("click", function (event) {
    const anchor = event.target.closest("a");
    if (anchor) persist();
  });
})();
