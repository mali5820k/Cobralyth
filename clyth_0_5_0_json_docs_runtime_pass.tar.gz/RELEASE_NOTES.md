# Clyth 0.5.0-alpha Release Notes

## Runtime Ecosystem Foundation Release

Clyth 0.5.0-alpha is the release where the project moves from "compiler experiment" toward "usable systems language/runtime alpha."

The release still keeps the compiler small, but it finishes several language hooks needed for real applications and expands the runtime into practical modules: file I/O, hashing, routing, HTTP/HTTPS API surfaces, JSON module direction, and backend dependency planning.

## Compiler Highlights

- Added explicit `this` support.
- Stabilized first-class function type syntax:

```clyth
function<ReturnType, <ParamType1, ParamType2>>
```

- Added lambda/callback syntax with named parameters:

```clyth
function<void, <Request request, Response response> => {
    response.send_json(200, "{\"ok\":true}")
}
```

- Added function values/callback invocation groundwork.
- Added struct constructor semantics, including default construction and constructor/function resolution order.
- Improved string lowering across runtime method calls, C ABI calls, string comparisons, and null checks.
- Converted the regression runner to return-code based validation.

## Runtime Highlights

- Added `file-io` runtime module.
- Added `hash` module backed by rapidhash.
- Added `router`, `http`, and `https` runtime module API surfaces.
- Added `json` runtime module boundary and early JSON value helpers.
- Added concurrency/threading direction through runtime modules rather than compiler-owned thread magic.
- Removed wslay as an official runtime-stack target.
- Confirmed OpenSSL-only TLS direction; wolfSSL is excluded due GPL/commercial licensing options.

## Backend Stack Direction

Clyth's backend runtime direction is:

```text
libuv    -> event loop, async file I/O, TCP, timers, worker scheduling
llhttp   -> HTTP/1.1 parser
OpenSSL  -> TLS/HTTPS
wslay    -> WebSocket framing after HTTP Upgrade
```

The public API remains Clyth-owned. These libraries are implementation components under Clyth runtime modules, not the user-facing design.

## Regression Suite

The numbered regression suite now covers 17 active tests and uses return-code validation. A test passes when the compiled program exits with code `0`; non-zero exit codes are failures.

Protected areas include:

- extern C calls
- arrays
- native strings
- runtime collections
- generics
- package includes
- DMA runtime include
- explicit `this`
- first-class function types
- file I/O
- hashing
- HTTPS/router API surface
- lambda callback invocation

## JSON Status

JSON is not yet a complete parser/stringifier. 0.5.0 establishes the JSON runtime module backed by yyjson and allows HTTP/HTTPS APIs to send JSON payload strings. Full `JSON.parse` and `JSON.stringify` support should land as runtime work rather than compiler work.

## Distribution Notes

`dist-clyth` packaging is now leaner. It should not include LLVM source trees, LLVM build directories, Zig toolchains, generated object caches, or vendor source checkouts.

## Next Focus

After 0.5.0, the project should focus on:

- hardening modules
- standalone module builds
- JSON parser/stringifier completion
- real HTTP/HTTPS server execution samples
- async/await and runtime task scheduling
- LSP/editor tooling
- MECC foundation work


### JSON Runtime Update

- Added yyjson-backed JSON runtime module wiring.
- Added JSON validation/root-kind API surface through `include "json"`.
- Added sample `18_0_5_json_runtime.clyth`.
- Clarified that libuv supports event loops, async I/O, TCP, timers, and worker scheduling; JSON parsing is owned by the JSON module backend.
